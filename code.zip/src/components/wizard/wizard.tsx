import { Box, Card, CardContent, Container, useTheme } from '@mui/material';

import {
    cardContentStyles,
    cardStyles,
    containerStyles,
    contentWrapperStyles,
    progressBarStyles,
} from './styles';
import { STEPS } from '../../constants';
import useWizardStore from '../../store/wizard-store';
import { WizardStepContent } from '../wizard-stepper/wizard-step-content';
import { WizardStepper } from '../wizard-stepper/wizard-stepper';

export const Wizard = () => {
    const theme = useTheme();
    const { activeStep } = useWizardStore();
    const currentStep = STEPS[activeStep];
    const isSuccessStep = Boolean(currentStep?.hideNavigation);

    return (
        <Container maxWidth="md" sx={containerStyles}>
            <Card elevation={0} sx={cardStyles(theme)}>
                {!isSuccessStep && <Box sx={progressBarStyles} />}
                <CardContent sx={cardContentStyles}>
                    <WizardStepper />
                    <Box sx={contentWrapperStyles(isSuccessStep)}>
                        <WizardStepContent />
                    </Box>
                </CardContent>
            </Card>
        </Container>
    );
};

export interface WizardNavigationProps {
  onSubmit?: () => void;
}

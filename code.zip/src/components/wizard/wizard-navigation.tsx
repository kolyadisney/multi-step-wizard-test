import { ArrowBack, ArrowForward, CheckCircle } from '@mui/icons-material';
import { Box, Button, useTheme } from '@mui/material';
import React from 'react';

import { navigationWrapperStyles, previousButtonStyles, nextButtonStyles } from './styles';
import { WizardNavigationProps } from './types';
import { STEPS } from '@/constants';
import useWizardStore from '@/store/wizard-store';

export const WizardNavigation: React.FC<WizardNavigationProps> = ({ onSubmit }) => {
    const theme = useTheme();
    const { activeStep, setActiveStep, isStepValid, setStepValid } = useWizardStore();

    const currentStep = React.useMemo(() => STEPS[activeStep], [activeStep]);

    if (currentStep?.hideNavigation) {
        return null;
    }

    const isFirstStep = React.useMemo(() => activeStep === 0, [activeStep]);
    const mainSteps = React.useMemo(() => STEPS.filter((step) => !step.hideNavigation), []);
    const isLastMainStep = React.useMemo(() => activeStep === mainSteps.length - 1, [activeStep, mainSteps]);

    React.useEffect(() => {
        if (isLastMainStep) {
            setStepValid(true);
        }
    }, [isStepValid, isLastMainStep, setStepValid]);

    return (
        <Box sx={navigationWrapperStyles(theme)}>
            <Button
                variant="contained"
                color="primary"
                onClick={() => setActiveStep(activeStep - 1)}
                disabled={isFirstStep}
                startIcon={<ArrowBack />}
                sx={previousButtonStyles(isFirstStep, theme)}
            >
                Previous
            </Button>
            <Button
                variant="contained"
                color={isLastMainStep ? 'success' : 'primary'}
                disabled={isLastMainStep ? false : !isStepValid}
                endIcon={isLastMainStep ? <CheckCircle /> : <ArrowForward />}
                sx={nextButtonStyles(isStepValid, isLastMainStep, theme)}
                {...(onSubmit
                    ? {
                        onClick: onSubmit,
                    }
                    : {
                        type: 'submit',
                    })}
            >
                {isLastMainStep ? 'Complete' : 'Next'}
            </Button>
        </Box>
    );
};

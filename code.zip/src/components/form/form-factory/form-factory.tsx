'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { ReactElement } from 'react';
import React from 'react';
import { Controller, useForm } from 'react-hook-form';
import { z } from 'zod';
import { Path } from 'react-hook-form';

import { AnimatedErrorMessage } from './animated-error-message';
import { formStyles, fieldContainerStyles } from './styles';
import { FormFactoryProps, FormField } from './types';
import useWizardStore from '@/store/wizard-store';
import { WizardNavigation } from '@/components/wizard/wizard-navigation';

export const FormFactory = <T extends z.ZodType>({
    fields,
    schema,
    onSubmit,
    defaultValues = {},
}: FormFactoryProps<T>) => {
    const { setStepValid } = useWizardStore();

    const {
        handleSubmit,
        control,
        formState: { errors, isValid },
    } = useForm<z.infer<T>>({
        resolver: zodResolver(schema),
        defaultValues: defaultValues as z.infer<T>,
        mode: 'onChange',
        reValidateMode: 'onChange'
    });

    const handleFormSubmit = async (data: z.infer<T>) => {
        try {
            await schema.parseAsync(data);
            setStepValid(true);
            onSubmit(data);
        } catch (error: unknown) {
            setStepValid(false);
        }
    };

    // Update validation state when form changes
    React.useEffect(() => {
        setStepValid(isValid);
    }, [isValid, setStepValid]);

    const renderField = (field: FormField<T>): ReactElement => {
        return (
            <>
                <Controller
                    key={String(field.name)}
                    name={field.name as Path<z.infer<T>>}
                    control={control}
                    render={({ field: controllerField }) => {
                        return field.render!({
                            field: controllerField,
                            error: errors[field.name]?.message as string,
                            label: field.label,
                            required: field.required,
                        }) as ReactElement;
                    }}
                />
                <AnimatedErrorMessage error={errors[field.name]?.message as string} />
            </>
        );
    };

    return (
        <form onSubmit={handleSubmit(handleFormSubmit)} style={formStyles}>
            {fields.map((field) => (
                <div key={String(field.name)} style={fieldContainerStyles}>
                    {renderField(field)}
                </div>
            ))}
            <WizardNavigation />
        </form>
    );
};

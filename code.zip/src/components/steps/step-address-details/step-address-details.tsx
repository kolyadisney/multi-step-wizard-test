import { LocationCity, LocationOn, Map, Pin } from '@mui/icons-material';
import React from 'react';
import { z } from 'zod';

import { FormFactory, FormField } from '@/components/form/form-factory';
import { FormTextField } from '@/components/form/form-text-field';
import useWizardStore from '@/store/wizard-store';
import { addressDetailsSchema } from '@/validation';

export const StepAddressDetails = () => {
  const { formData, updateFormData, setActiveStep, activeStep } = useWizardStore();

  const handleSubmit = (data: z.infer<typeof addressDetailsSchema>) => {
    updateFormData(data);
    setActiveStep(activeStep + 1);
  };

  const fields = React.useMemo<FormField<typeof addressDetailsSchema>[]>(() => {
    return [
      {
        name: 'street',
        label: 'Street',
        type: 'text',
        required: true,
        render: ({ field, label, required, error }) => {
          return (
            <FormTextField
              name={field.name}
              value={field.value}
              onChange={field.onChange}
              error={error}
              textFieldProps={{
                label,
                required,
              }}
              startIcon={<Map />}
            />
          );
        },
      },
      {
        name: 'city',
        label: 'City',
        type: 'text',
        required: true,
        render: ({ field, label, required, error }) => {
          return (
            <FormTextField
              name={field.name}
              value={field.value}
              onChange={field.onChange}
              error={error}
              textFieldProps={{
                label,
                required,
              }}
              startIcon={<LocationCity />}
            />
          );
        },
      },
      {
        name: 'state',
        label: 'State',
        type: 'text',
        required: true,
        render: ({ field, label, required, error }) => {
          return (
            <FormTextField
              name={field.name}
              value={field.value}
              onChange={field.onChange}
              error={error}
              textFieldProps={{
                label,
                required,
              }}
              startIcon={<LocationOn />}
            />
          );
        },
      },
      {
        name: 'zipCode',
        label: 'Zip Code',
        type: 'text',
        required: true,
        render: ({ field, label, required, error }) => {
          return (
            <FormTextField
              name={field.name}
              value={field.value}
              onChange={field.onChange}
              error={error}
              textFieldProps={{
                label,
                required,
              }}
              startIcon={<Pin />}
            />
          );
        },
      },
    ];
  }, []);
  return (
    <FormFactory
      fields={fields}
      schema={addressDetailsSchema}
      onSubmit={handleSubmit}
      defaultValues={formData}
    />
  );
};

export interface HeaderProps {
  title: string;
}

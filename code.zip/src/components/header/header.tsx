import { AppBar, SxProps, Theme, Toolbar, Typography } from '@mui/material';

import { HeaderProps } from './types';
import { ThemeSwitcher } from '../theme-switcher';
export const Header: React.FC<HeaderProps> = ({ title }) => {
  return (
    <AppBar position="static" component="header">
      <Toolbar sx={toolbarStyles}>
        <Typography variant="h6">{title}</Typography>
        <ThemeSwitcher />
      </Toolbar>
    </AppBar>
  );
};

const toolbarStyles: SxProps<Theme> = {
  justifyContent: 'space-between',
  alignItems: 'center',
};

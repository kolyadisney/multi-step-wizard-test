import { StepIconProps } from '@mui/material';

export interface CustomStepIconProps extends StepIconProps {
  label: string;
}

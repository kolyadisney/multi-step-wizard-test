import { Box, Typography } from '@mui/material';
import { STEPS } from '@/constants';
import useWizardStore from '@/store/wizard-store';
import { stepTitleStyles } from './styles';

export const WizardStepContent = () => {
    const { activeStep } = useWizardStore();
    const currentStep = STEPS[activeStep];
    const StepComponent = currentStep.component;
    const isLastStep = currentStep?.hideNavigation;

    return (
        <>
            <Typography variant="h5" sx={stepTitleStyles} visibility={isLastStep ? 'hidden' : 'visible'}>
                {currentStep.label}
            </Typography>
            <Box>
                <StepComponent />
            </Box>
        </>
    );
};

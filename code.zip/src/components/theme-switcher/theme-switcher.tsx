import { NightsStay, WbSunny } from '@mui/icons-material';
import { Button } from '@mui/material';

import useWizardStore from '@/store/wizard-store';

export const ThemeSwitcher = () => {
  const { themeMode, setThemeMode } = useWizardStore();
  return (
    <Button
      variant="outlined"
      onClick={() => setThemeMode(themeMode === 'light' ? 'dark' : 'light')}
    >
      {themeMode === 'light' ? (
        <NightsStay sx={{ color: 'white' }} />
      ) : (
        <WbSunny sx={{ color: 'white' }} />
      )}
    </Button>
  );
};

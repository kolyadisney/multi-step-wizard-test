import { CssBaseline, useMediaQuery } from '@mui/material';
import { ThemeProvider } from '@mui/material/styles';
import React from 'react';

import { Header } from './components';
import { Wizard } from './components/wizard/wizard';
import useWizardStore from './store/wizard-store';
import { getTheme } from './theme/theme';

function App() {
  const { themeMode, setThemeMode } = useWizardStore();
  const prefersDarkMode = useMediaQuery('(prefers-color-scheme: dark)');

  React.useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
      setThemeMode(savedTheme as 'light' | 'dark');
    } else if (prefersDarkMode) {
      setThemeMode('dark');
    }
  }, [prefersDarkMode, setThemeMode]);

  return (
    <ThemeProvider theme={getTheme(themeMode)}>
      <CssBaseline />
      <Header title="Wizard Form" />
      <Wizard />
    </ThemeProvider>
  );
}

export default App;

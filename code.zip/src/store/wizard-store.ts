import { create } from 'zustand';
import { WizardData } from '../validation';
import { devtools } from 'zustand/middleware';

const initialFormData: Partial<WizardData> = {
    // User Details
    firstName: '',
    lastName: '',
    email: '',

    // Address Details
    street: '',
    city: '',
    state: '',
    zipCode: '',

    // Account Details
    username: '',
    password: '',
    confirmPassword: '',
};

export interface WizardStore {
    activeStep: number;
    setActiveStep: (step: number) => void;
    formData: Partial<WizardData>;
    updateFormData: (data: Partial<WizardData>) => void;
    resetFormData: () => void;
    isStepValid: boolean;
    setStepValid: (isValid: boolean) => void;
    themeMode: 'light' | 'dark';
    setThemeMode: (mode: 'light' | 'dark') => void;
}

const useWizardStore = create<WizardStore>()(
    devtools(
        (set) => ({
            activeStep: 0,
            setActiveStep: (step: number) => set({ activeStep: step }),
            formData: initialFormData,
            updateFormData: (data: Partial<WizardData>) =>
                set((state) => ({ formData: { ...state.formData, ...data } })),
            resetFormData: () => set({ formData: initialFormData }),
            isStepValid: false,
            setStepValid: (isValid: boolean) => set({ isStepValid: isValid }),
            themeMode: 'light',
            setThemeMode: (mode: 'light' | 'dark') => set({ themeMode: mode }),
        }),
        {
            name: 'wizard-store',
        },
    ),
);

export default useWizardStore;
